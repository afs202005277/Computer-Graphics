# CG 2022/2023

## Group T02G05

## TP 3 Notes


- Exercise 7: Since we are defining the normals in each vertex of the lateral face and the 4 normals are parallel, it is the same as using constant shading in that face.
- While building the prism we had several difficulties in filling the indices array.



![Screenshot 1](screenshots/cg-t02g05-tp3-1.png)

![Screenshot 2](screenshots/cg-t02g05-tp3-2.png)

![Screenshot 3](screenshots/cg-t02g05-tp3-3.png)

![Screenshot 4](screenshots/cg-t02g05-tp3-4.png)

