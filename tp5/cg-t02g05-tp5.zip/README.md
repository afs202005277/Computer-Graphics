# CG 2022/2023

## Group T02G05

## TP 5 Notes

With these exercises we improved our knowledge regarding the use of shaders.

Overall we had several difficulties in the general usage of shaders, namely in:
- Understanding shader basics
- Shader language syntax
- Shader debugging
- Shader optimization


![Screenshot 1](screenshots/cg-t02g05-tp5-1.png)

![Screenshot 2](screenshots/cg-t02g05-tp5-2.png)

![Screenshot 3](screenshots/cg-t02g05-tp5-3.png)


