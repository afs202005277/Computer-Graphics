# CG 2022/2023

## Group T02G05

## TP 4 Notes

With these exercises we improved our knowledge regarding the mapping of textures into 3D objects.

Furthermore, we also developed our understanding of the filtering concept.


![Screenshot 1](screenshots/cg-t02g05-tp4-1.png)

![Screenshot 2](screenshots/cg-t02g05-tp4-2.png)


